package Principal;

import model.ChatMadiator;
import model.ChatMediatorImp;
import model.Usuario;
import model.UsuarioImp;

public class Teste {
	
	public static void main(String[] args) {
		ChatMadiator chat = new ChatMediatorImp();
		Usuario u1 = new UsuarioImp("Antonio", chat);
		Usuario u2 = new UsuarioImp("Ana", chat);
		Usuario u3 = new UsuarioImp("Maria", chat);
		Usuario u4 = new UsuarioImp("Pedro", chat);
		
		chat.adicionarUsuario(u1);
		chat.adicionarUsuario(u2);
		chat.adicionarUsuario(u3);
		chat.adicionarUsuario(u4);
		
		u1.enviarMensagem("Bom dia!");
	}

}
