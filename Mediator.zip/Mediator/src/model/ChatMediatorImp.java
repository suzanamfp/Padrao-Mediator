package model;

import java.util.ArrayList;
import java.util.List;

public class ChatMediatorImp implements ChatMadiator{
	
	private List<Usuario>usuarios;
	

	public ChatMediatorImp() {
		this.usuarios = new ArrayList<Usuario>();
	}

	@Override
	public void enviarMensagem(String mensagem, Usuario user) {
		for (Usuario usuario : this.usuarios) {
			if(usuario != user) {
				usuario.receberMensagem(mensagem);
			}
		}
	}

	@Override
	public void adicionarUsuario(Usuario user) {
		usuarios.add(user);
	}

}
