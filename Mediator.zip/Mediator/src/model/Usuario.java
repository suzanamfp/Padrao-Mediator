package model;

public abstract class Usuario {
	
	protected String nome;
	protected ChatMadiator mediator;
	
	public Usuario(String nome, ChatMadiator mediator) {
		this.nome = nome;
		this.mediator = mediator;
	}
	
	public abstract void enviarMensagem (String mensagem); 
	
	public abstract void receberMensagem (String mensagem);
}
