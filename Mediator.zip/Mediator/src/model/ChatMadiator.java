package model;

public interface ChatMadiator {
	
	public void enviarMensagem(String mensagem, Usuario user);
	
	public void adicionarUsuario(Usuario user);
}
